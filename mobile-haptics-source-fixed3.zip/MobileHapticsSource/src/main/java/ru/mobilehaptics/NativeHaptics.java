package ru.mobilehaptics;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NativeHaptics {
    private static final Logger LOGGER = LoggerFactory.getLogger("MobileHaptics");
    private static volatile boolean available = false;
    private static Path extracted;

    private NativeHaptics() {}

    public static void init() {
        if (!isAndroidBridgeEnvironment()) {
            LOGGER.info("Android native bridge environment was not detected; haptics will be disabled on this runtime.");
            return;
        }
        try {
            String resource = nativeResourceForCurrentArch();
            if (resource == null) {
                LOGGER.warn("Unsupported CPU architecture for bundled haptic bridge.");
                return;
            }
            try (InputStream in = NativeHaptics.class.getResourceAsStream(resource)) {
                if (in == null) {
                    LOGGER.warn("Bundled native library is missing: {}", resource);
                    return;
                }
                Path dir = FabricLoader.getInstance().getConfigDir().resolve("mobilehaptics-native");
                Files.createDirectories(dir);
                extracted = dir.resolve("libmobilehaptics.so");
                Files.copy(in, extracted, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            System.load(extracted.toAbsolutePath().toString());
            long vm = parsePointer(System.getenv("DALVIK_JAVAVM"));
            long app = parsePointer(System.getenv("DALVIK_APPLICATION"));
            if (vm == 0 || app == 0) {
                LOGGER.warn("DALVIK_JAVAVM or DALVIK_APPLICATION is missing.");
                return;
            }
            nativeInit(vm, app);
            available = true;
            LOGGER.info("Android haptic native bridge initialized.");
        } catch (Throwable t) {
            LOGGER.warn("Could not initialize Android haptics; continuing without vibration.", t);
        }
    }

    public static void vibrate(int durationMs, int amplitude) {
        if (!available || !MobileHapticsConfig.enabled) return;
        int duration = Math.max(1, Math.min(1000, durationMs));
        int amp = Math.max(1, Math.min(255, amplitude));
        try {
            nativeVibrate(duration, amp);
        } catch (Throwable t) {
            available = false;
            LOGGER.debug("Haptic call failed", t);
        }
    }

    private static boolean isAndroidBridgeEnvironment() {
        return System.getenv("DALVIK_JAVAVM") != null && System.getenv("DALVIK_APPLICATION") != null;
    }

    private static String nativeResourceForCurrentArch() {
        String arch = System.getProperty("os.arch", "").toLowerCase();
        if (arch.contains("aarch64") || arch.contains("arm64")) {
            return "/native/arm64-v8a/libmobilehaptics.so";
        }
        if (arch.contains("amd64") || arch.contains("x86_64")) {
            return "/native/x86_64/libmobilehaptics.so";
        }
        return null;
    }

    private static long parsePointer(String raw) {
        if (raw == null) return 0;
        String s = raw.trim();
        if (s.isEmpty()) return 0;
        try {
            if (s.startsWith("0x") || s.startsWith("0X")) return Long.parseLong(s.substring(2), 16);
            boolean hex = s.matches(".*[a-fA-F].*");
            return Long.parseLong(s, hex ? 16 : 10);
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private static native void nativeInit(long javaVmPtr, long applicationPtr);
    private static native void nativeVibrate(int durationMs, int amplitude);
}
